## Part One 
### Midway Image

In this part of the project, we define the midway image between too faces. We do this by triangulating two images, finding the halfway shape between the two images, morphing the images to those shapes piecewise linearly. Though I did most of the project in Haskell, I found the triangulation in python because all ofthe Delaunay triangulation libraries for haskell seems to be broken in some way. 

![Me](images/gaugau.jpg){ height=400 }

![Obama](images/44.jpeg){ height=400 }

![Me, Triangulated](images/gaurpts.jpg){ height=400 }

![Obama, Triangulated](images/obpts.jpg){ height=400 }

![Midway Image](images/gauravObamap23.jpg){ height=400 }

## Morph Sequence

Here we interpolate the points and the texture smoothly from the first image to the second image. The result is below. 

![Morph](images/output.gif){ height=400 }

## Average Face

We compute the average of the brazil dataset, and convert me to the average shape, and the average texture onto me.

![Average Person](images/average.jpg){ height=400 }

![Me to Average](images/toAverage.jpg)

![Me from Average](images/fromAverage.jpg)

## Charicature

We, we interpolate my face shape past 1, ie creating a caricature of my face.

![Caricature](images/toCari3.jpg)
